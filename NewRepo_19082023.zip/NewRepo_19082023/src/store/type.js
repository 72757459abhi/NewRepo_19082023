const Type={
    "LOGIN":"LOGIN",
    "TOKEN": "TOKEN",
     "USERDETAILS": "USERDETAILS",
     "JSONDATA":"JSONDATA"
}

export default Type