import React from 'react'
import classes from '../cssFile/About.module.css';

const About = () => {
  return (
    <main className={classes.profile}>
     
    </main>
  );
};

export default About;
